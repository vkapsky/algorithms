package lab6;

public class House {
    public int houseNumber;
    public House(int houseNumber){
        this.houseNumber=houseNumber;
    }
    public void setHouseNumber(){
        this.houseNumber=houseNumber;
    }
    public int getHouseNumber(){
        return houseNumber;
    }
}
